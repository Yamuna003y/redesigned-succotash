// Function to handle form submission
function submitForm() {
    // Get form inputs
    var fullName = document.getElementById("fullName").value;
    var email = document.getElementById("email").value;
    var organType = document.getElementById("organType").value;
    
    // Validate form inputs
    if (fullName === "" || email === "" || organType === "") {
      alert("Please fill in all fields.");
      return;
    }
    
    // Send form data to server or perform further actions
    // Example: You can make an AJAX request to send the form data to a server
    
    // Display success message
    alert("Thank you, " + fullName + "! Your organ donation form has been submitted.");
  }
  

